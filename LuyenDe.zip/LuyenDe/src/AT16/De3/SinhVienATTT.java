/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AT16.De3;

/**
 *
 * @author admin
 */
public class SinhVienATTT extends SinhVien {
    private int hocPhi;

    public SinhVienATTT(String msv, String hoTen, String ngaySinh, String gioiTinh, double gpa, int hocPhi) {
        super(msv, hoTen, ngaySinh, gioiTinh, gpa);
        this.hocPhi = hocPhi;
    }

    public int getHocPhi() {
        return hocPhi;
    }

    public void setHocPhi(int hocPhi) {
        this.hocPhi = hocPhi;
    }

    @Override
    public String hienThiThongTin() {
        String s = super.hienThiThongTin();
        return "SinhVienATTT{" + s + "hocPhi=" + hocPhi + '}';
    }
}
