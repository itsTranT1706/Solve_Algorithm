/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AT16.De1;

/**
 *
 * @author admin
 */
public class Student extends Person {
    private String maSV, email;
    private double gpa;

    public Student() {
    }

    public Student(String hoTen, String ngaySinh, String diaChi, String gioiTinh, String maSV, String email, double gpa) {
        super(hoTen, ngaySinh, diaChi, gioiTinh);
        this.maSV = maSV;
        this.email = email;
        this.gpa = gpa;
    }

    public String getMaSV() {
        return maSV;
    }

    public void setMaSV(String maSV) {
        this.maSV = maSV;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public double getGpa() {
        return gpa;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }
    
    @Override
    public String hienThiThongTin() {
        String s = super.hienThiThongTin();
        return "Student{" + s + "maSV=" + maSV + ", email=" + email + ", gpa=" + gpa + '}';
    }
}
