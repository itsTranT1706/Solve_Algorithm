/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AT16.De4;

import java.util.ArrayList;

/**
 *
 * @author admin
 */
public class Word {
    private int id;
    private String en;
    private ArrayList<String> vn;

    public Word() {
    }

    public Word(int id, String en, ArrayList<String> vn) {
        this.id = id;
        this.en = en;
        this.vn = vn;
    }

    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEn() {
        return en;
    }

    public void setEn(String en) {
        this.en = en;
    }

    public ArrayList<String> getVn() {
        return vn;
    }

    public void setVn(ArrayList<String> vn) {
        this.vn = vn;
    }

    

    @Override
    public String toString() {
        return "Word{" + "id=" + id + ", en=" + en + ", vn=" + vn + '}';
    }
}
