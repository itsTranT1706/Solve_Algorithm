/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AT16.De4;

import java.util.ArrayList;

/**
 *
 * @author admin
 */
public class Dictionary {
    private ArrayList<Word> danhSachTuDien;

    public Dictionary() {
        danhSachTuDien = new ArrayList<>();
        danhSachTuDien.add(new Word(1, "One", new ArrayList<>() {{add("1"); add("Số 1"); add("Số một");}}));
        danhSachTuDien.add(new Word(2, "Two", new ArrayList<>() {{add("2"); add("Số 2"); add("Số hai");}}));
        danhSachTuDien.add(new Word(3, "Three", new ArrayList<>() {{add("3"); add("Số 3"); add("Số ba");}}));
        danhSachTuDien.add(new Word(4, "Four", new ArrayList<>() {{add("4"); add("Số 4"); add("Số bốn");}}));
        danhSachTuDien.add(new Word(5, "Five", new ArrayList<>() {{add("5"); add("Số 5"); add("Số năm");}}));
        danhSachTuDien.add(new Word(6, "Six", new ArrayList<>() {{add("6"); add("Số 6"); add("Số sáu");}}));
        danhSachTuDien.add(new Word(7, "Seven", new ArrayList<>() {{add("7"); add("Số 7"); add("Số bảy");}}));
        danhSachTuDien.add(new Word(8, "Eight", new ArrayList<>() {{add("8"); add("Số 8"); add("Số tám");}}));
        danhSachTuDien.add(new Word(9, "Nine", new ArrayList<>() {{add("9"); add("Số 9"); add("Số chín");}}));
        danhSachTuDien.add(new Word(10, "Ten", new ArrayList<>() {{add("10"); add("Số 10"); add("Số mười");}}));
        danhSachTuDien.add(new Word(11, "Eleven", new ArrayList<>() {{add("11"); add("Số 11"); add("Số mười một");}}));
    }
    
    public ArrayList<Word> getDanhSachTuDien() {
        return danhSachTuDien;
    }
}
